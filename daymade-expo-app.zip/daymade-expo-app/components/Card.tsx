import React from 'react';
import { View } from 'react-native';

export const Card: React.FC<{children?: React.ReactNode, style?: any}> = ({ children, style }) => (
  <View style={[{ backgroundColor:'#fff', borderRadius:14, borderWidth:1, borderColor:'#E5E7EB', padding:12, shadowColor:'#000', shadowOpacity:0.05, shadowRadius:8, marginBottom:8 }, style]}>
    {children}
  </View>
);
