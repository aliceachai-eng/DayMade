import { Tabs } from 'expo-router';
export default function RootLayout() {
  return (
    <Tabs>
      <Tabs.Screen name="(tabs)/index" options={{ title: 'Home' }} />
      <Tabs.Screen name="(tabs)/tasks" options={{ title: 'Tasks' }} />
      <Tabs.Screen name="(tabs)/chat" options={{ title: 'Concierge' }} />
      <Tabs.Screen name="(tabs)/vendors" options={{ title: 'Vendors' }} />
      <Tabs.Screen name="(tabs)/operator" options={{ title: 'Operator' }} />
    </Tabs>
  );
}
