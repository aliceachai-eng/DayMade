import React, { useEffect } from 'react';
import { View, Text, Pressable, ScrollView } from 'react-native';
import { Link } from 'expo-router';
import { useStore } from '@/lib/store';
import { Card } from '@/components/Card';

export default function Home() {
  const { member, setMember, hydrate, tasks } = useStore();
  useEffect(()=>{ hydrate(); }, []);
  return (
    <ScrollView style={{flex:1, backgroundColor:'#F3F4F6'}} contentContainerStyle={{padding:16, gap:12}}>
      <View style={{flexDirection:'row', alignItems:'center', gap:12}}>
        <View style={{width:44,height:44, borderRadius:12, backgroundColor:'#4F46E5', alignItems:'center', justifyContent:'center'}}>
          <Text style={{color:'#fff', fontWeight:'800'}}>DM</Text>
        </View>
        <View>
          <Text style={{fontSize:18, fontWeight:'600'}}>DayMade</Text>
          <Text style={{color:'#6B7280'}}>Your day, made easier.</Text>
        </View>
      </View>
      <Card>
        <Text style={{fontSize:16, fontWeight:'600', marginBottom:6}}>Membership</Text>
        <Text style={{color:'#6B7280', marginBottom:10}}>{member.planId ? `${member.planId.toUpperCase()} plan active` : 'No plan selected'}</Text>
        <View style={{flexDirection:'row', gap:8}}>
          {['lite','plus','premium'].map(p => (
            <Pressable key={p} onPress={()=>setMember({ planId: p as any })} style={{paddingVertical:8,paddingHorizontal:12, borderRadius:10, borderWidth:1, borderColor:'#E5E7EB', backgroundColor: member.planId===p ? '#EEF2FF' : '#fff'}}>
              <Text style={{fontWeight:'600'}}>{p}</Text>
            </Pressable>
          ))}
        </View>
        <Text style={{color:'#6B7280', marginTop:8}}>Checkout is mocked. Replace with Stripe when ready.</Text>
      </Card>
      <View style={{flexDirection:'row', gap:10}}>
        <Link href="/(tabs)/tasks/new" asChild>
          <Pressable style={{padding:12, backgroundColor:'#10B981', borderRadius:12}}><Text style={{color:'#fff', fontWeight:'700'}}>New Task</Text></Pressable>
        </Link>
        <Link href="/(tabs)/chat" asChild>
          <Pressable style={{padding:12, backgroundColor:'#2563EB', borderRadius:12}}><Text style={{color:'#fff', fontWeight:'700'}}>Concierge</Text></Pressable>
        </Link>
      </View>
      <Text style={{fontWeight:'600', marginTop:12}}>Active tasks</Text>
      {tasks.filter(t=>t.status!=='done').slice(0,3).map(t => (
        <Card key={t.id}>
          <Text style={{fontWeight:'600'}}>{t.title}</Text>
          <Text style={{color:'#6B7280'}}>{t.category} • {new Date(t.scheduledAt).toLocaleString()}</Text>
        </Card>
      ))}
      {tasks.filter(t=>t.status!=='done').length===0 && <Text style={{color:'#6B7280'}}>No active tasks yet.</Text>}
      <Link href="/(tabs)/tasks" style={{color:'#2563EB', marginTop:6}}>View all tasks →</Link>
    </ScrollView>
  );
}
