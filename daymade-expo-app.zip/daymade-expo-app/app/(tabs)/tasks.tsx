import React from 'react';
import { View, Text, ScrollView, Pressable } from 'react-native';
import { Link } from 'expo-router';
import { useStore } from '@/lib/store';
import { Card } from '@/components/Card';

export default function Tasks() {
  const { tasks, advanceStatus } = useStore();
  const active = tasks.filter(t=>t.status!=='done');
  const completed = tasks.filter(t=>t.status==='done');
  return (
    <ScrollView style={{flex:1, backgroundColor:'#F3F4F6'}} contentContainerStyle={{padding:16, gap:12}}>
      <View style={{flexDirection:'row', justifyContent:'space-between', alignItems:'center'}}>
        <Text style={{fontSize:20, fontWeight:'700'}}>Tasks</Text>
        <Link href="/(tabs)/tasks/new" asChild>
          <Pressable style={{paddingVertical:8, paddingHorizontal:12, backgroundColor:'#10B981', borderRadius:10}}><Text style={{color:'#fff'}}>New</Text></Pressable>
        </Link>
      </View>
      <Text style={{fontWeight:'600'}}>Active</Text>
      {active.map(t=> (
        <Card key={t.id}>
          <View style={{flexDirection:'row', justifyContent:'space-between'}}>
            <View>
              <Text style={{fontWeight:'600'}}>{t.title}</Text>
              <Text style={{color:'#6B7280'}}>{t.category} • {new Date(t.scheduledAt).toLocaleString()}</Text>
              {t.vendorId && <Text>Assigned to: {t.vendorId}</Text>}
            </View>
            <Pressable onPress={()=>advanceStatus(t.id)} style={{paddingVertical:6, paddingHorizontal:10, backgroundColor:'#EEF2FF', borderRadius:8}}>
              <Text>Advance</Text>
            </Pressable>
          </View>
        </Card>
      ))}
      {active.length===0 && <Text style={{color:'#6B7280'}}>No active tasks.</Text>}
      <Text style={{fontWeight:'600', marginTop:10}}>Completed</Text>
      {completed.map(t=> (
        <Card key={t.id}>
          <Text style={{fontWeight:'600'}}>{t.title}</Text>
          <Text style={{color:'#6B7280'}}>{new Date(t.createdAt).toLocaleDateString()}</Text>
        </Card>
      ))}
      {completed.length===0 && <Text style={{color:'#6B7280'}}>Nothing completed yet.</Text>}
    </ScrollView>
  );
}
