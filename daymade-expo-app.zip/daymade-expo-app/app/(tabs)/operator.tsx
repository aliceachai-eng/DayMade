import React, { useState } from 'react';
import { View, Text, TextInput, ScrollView, Pressable } from 'react-native';
import { useStore } from '@/lib/store';
import { Card } from '@/components/Card';

export default function Operator() {
  const { tasks, vendors, addVendor, assignVendor, advanceStatus } = useStore();
  const [name, setName] = useState('');
  const [cats, setCats] = useState('errands');

  return (
    <ScrollView style={{flex:1, backgroundColor:'#F3F4F6'}} contentContainerStyle={{padding:16, gap:12}}>
      <Text style={{fontSize:20, fontWeight:'700'}}>Operator Panel</Text>
      {tasks.map(t => (
        <Card key={t.id}>
          <Text style={{fontWeight:'600'}}>{t.title}</Text>
          <Text style={{color:'#6B7280'}}>{t.category} • {t.status}</Text>
          <View style={{flexDirection:'row', flexWrap:'wrap', gap:6, marginTop:8}}>
            {vendors.filter(v=>v.cats.includes(t.category)).map(v => (
              <Pressable key={v.id} onPress={()=>assignVendor(t.id, v)} style={{padding:8, borderWidth:1, borderColor:'#E5E7EB', borderRadius:10}}>
                <Text>{v.name}</Text>
              </Pressable>
            ))}
          </View>
          <Pressable onPress={()=>advanceStatus(t.id)} style={{marginTop:8, padding:10, backgroundColor:'#EEF2FF', borderRadius:10}}>
            <Text>Advance Status</Text>
          </Pressable>
        </Card>
      ))}
      <Card>
        <Text style={{fontWeight:'600', marginBottom:6}}>Add Partner</Text>
        <TextInput placeholder="Business name" value={name} onChangeText={setName} style={{backgroundColor:'#fff', borderWidth:1, borderColor:'#E5E7EB', borderRadius:10, padding:10, marginBottom:8}} />
        <TextInput placeholder="Categories (comma, e.g. errands,delivery)" value={cats} onChangeText={setCats} style={{backgroundColor:'#fff', borderWidth:1, borderColor:'#E5E7EB', borderRadius:10, padding:10}} />
        <Pressable onPress={()=>{ if(name.trim()) { addVendor({ name: name.trim(), cats: cats.split(',').map(s=>s.trim()) as any, rating: 4.5, price: '$$', etaMin: 120 }); setName(''); } }} style={{marginTop:8, padding:10, backgroundColor:'#10B981', borderRadius:10, alignItems:'center'}}>
          <Text style={{color:'#fff', fontWeight:'700'}}>Add</Text>
        </Pressable>
      </Card>
    </ScrollView>
  );
}
