import React, { useState } from 'react';
import { View, Text, TextInput, ScrollView, Pressable } from 'react-native';
import { useStore } from '@/lib/store';

export default function Chat() {
  const { msgs, sendMsg } = useStore();
  const [text, setText] = useState('');
  return (
    <View style={{flex:1, backgroundColor:'#F3F4F6'}}>
      <ScrollView contentContainerStyle={{padding:16, gap:8}}>
        {msgs.map(m => (
          <View key={m.id} style={{alignSelf: m.role==='user' ? 'flex-end' : 'flex-start', maxWidth:'80%', backgroundColor: m.role==='user' ? '#2563EB' : '#fff', padding:10, borderRadius:12}}>
            <Text style={{color: m.role==='user' ? '#fff' : '#111827'}}>{m.text}</Text>
            <Text style={{fontSize:10, color: m.role==='user' ? '#E0E7FF' : '#6B7280'}}>{new Date(m.ts).toLocaleTimeString()}</Text>
          </View>
        ))}
      </ScrollView>
      <View style={{flexDirection:'row', gap:8, padding:12, borderTopWidth:1, borderColor:'#E5E7EB', backgroundColor:'#fff'}}>
        <TextInput value={text} onChangeText={setText} placeholder="Type a request…" style={{flex:1, borderWidth:1, borderColor:'#E5E7EB', borderRadius:10, padding:10}} />
        <Pressable onPress={()=>{ if(text.trim()) { sendMsg(text.trim()); setText(''); } }} style={{paddingHorizontal:14, justifyContent:'center', backgroundColor:'#2563EB', borderRadius:10}}>
          <Text style={{color:'#fff', fontWeight:'700'}}>Send</Text>
        </Pressable>
      </View>
    </View>
  );
}
