import React, { useState } from 'react';
import { View, Text, TextInput, ScrollView, Pressable } from 'react-native';
import { router } from 'expo-router';
import { useStore } from '@/lib/store';

export default function TaskNew() {
  const { addTask } = useStore();
  const [category, setCategory] = useState<'errands'|'groceries'|'pet'|'home'|'delivery'>('errands');
  const [title, setTitle] = useState('');
  const [details, setDetails] = useState('');
  const [from, setFrom] = useState('');
  const [to, setTo] = useState('');
  const [urgency, setUrgency] = useState(2);
  const when = new Date(Date.now()+60*60*1000).toISOString();

  const submit = () => {
    addTask({ title: title || `${category} request`, details, category, addressFrom: from, addressTo: to, urgency, scheduledAt: when, recurrence: 'none', creditsUsed: urgency>=4 ? 2 : 1 });
    router.back();
  };

  return (
    <ScrollView style={{flex:1, backgroundColor:'#F3F4F6'}} contentContainerStyle={{padding:16, gap:12}}>
      <Text style={{fontSize:20, fontWeight:'700'}}>New Task</Text>
      <Text>Category</Text>
      <View style={{flexDirection:'row', flexWrap:'wrap', gap:8}}>
        {(['errands','groceries','pet','home','delivery'] as const).map(c => (
          <Pressable key={c} onPress={()=>setCategory(c)} style={{padding:8, borderWidth:1, borderColor:'#E5E7EB', borderRadius:10, backgroundColor: category===c ? '#DCFCE7' : '#fff'}}>
            <Text style={{textTransform:'capitalize'}}>{c}</Text>
          </Pressable>
        ))}
      </View>
      <Text>Title</Text>
      <TextInput value={title} onChangeText={setTitle} placeholder="Short summary" style={{backgroundColor:'#fff', borderRadius:10, padding:10, borderWidth:1, borderColor:'#E5E7EB'}} />
      <Text>Details</Text>
      <TextInput value={details} onChangeText={setDetails} placeholder="Anything we should know?" multiline numberOfLines={3} style={{backgroundColor:'#fff', borderRadius:10, padding:10, borderWidth:1, borderColor:'#E5E7EB'}} />
      <Text>Pickup / From</Text>
      <TextInput value={from} onChangeText={setFrom} placeholder="123 Main St" style={{backgroundColor:'#fff', borderRadius:10, padding:10, borderWidth:1, borderColor:'#E5E7EB'}} />
      <Text>Dropoff / To</Text>
      <TextInput value={to} onChangeText={setTo} placeholder="456 Park Ave" style={{backgroundColor:'#fff', borderRadius:10, padding:10, borderWidth:1, borderColor:'#E5E7EB'}} />
      <Pressable onPress={submit} style={{padding:14, backgroundColor:'#10B981', borderRadius:12, alignItems:'center'}}>
        <Text style={{color:'#fff', fontWeight:'700'}}>Create Task</Text>
      </Pressable>
    </ScrollView>
  );
}
