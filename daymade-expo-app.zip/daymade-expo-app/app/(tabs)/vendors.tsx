import React from 'react';
import { Text, ScrollView } from 'react-native';
import { useStore } from '@/lib/store';
import { Card } from '@/components/Card';

export default function Vendors() {
  const { vendors } = useStore();
  return (
    <ScrollView style={{flex:1, backgroundColor:'#F3F4F6'}} contentContainerStyle={{padding:16, gap:12}}>
      <Text style={{fontSize:20, fontWeight:'700'}}>Partner Marketplace</Text>
      {vendors.map(v => (
        <Card key={v.id}>
          <Text style={{fontWeight:'600'}}>{v.name}</Text>
          <Text style={{color:'#6B7280'}}>{v.cats.join(', ')} • ⭐ {v.rating} • {v.price} • ETA ~{v.etaMin}m</Text>
        </Card>
      ))}
    </ScrollView>
  );
}
