# DayMade — Expo App (Mobile + Expo Go)

A ready-to-run DayMade MVP for phones. Features:
- Membership picker (mocked)
- Task creation & list
- Concierge chat stub that auto-creates tasks
- Partner marketplace & operator panel
- Local persistence via AsyncStorage

## Open instantly in Expo Go (via GitHub + Expo Cloud)

1) Create a new **public GitHub repo** named `daymade-expo-app`.
2) Upload everything in this folder to that repo.
   - On phone: go to github.com → `+` → **New repository** → create → **Add file** → **Upload files** → choose the zip contents.
3) Visit **expo.dev**, sign in, tap **Create project** → **Import from GitHub** → pick your repo.
4) After Expo finishes linking, tap **Publish**. A QR code appears.
5) Open **Expo Go** on your phone and scan the QR to run the app.

## Local (optional)
- `npm install`
- `npm run start`

> Replace mocked checkout/chat with Stripe & Twilio when ready.
