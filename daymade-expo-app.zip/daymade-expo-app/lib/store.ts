import create from 'zustand';
import AsyncStorage from '@react-native-async-storage/async-storage';
import dayjs from 'dayjs';

export type TaskStatus = 'new'|'assigned'|'en-route'|'in-progress'|'done';
export type Category = 'errands'|'groceries'|'pet'|'home'|'delivery';

export interface Task {
  id: string;
  title: string;
  details?: string;
  category: Category;
  addressFrom?: string;
  addressTo?: string;
  urgency: number;
  scheduledAt: string;
  recurrence: 'none'|'weekly'|'biweekly'|'monthly';
  creditsUsed: number;
  vendorId?: string;
  status: TaskStatus;
  createdAt: string;
}

export interface Vendor {
  id: string;
  name: string;
  cats: Category[];
  rating: number;
  price: '$'|'$$'|'$$$';
  etaMin: number;
}

export interface Member {
  planId: ''|'lite'|'plus'|'premium';
  name?: string;
  email?: string;
}

const uid = () => Math.random().toString(36).slice(2,10);
const nowISO = () => new Date().toISOString();
const STORAGE_KEY = 'dm_store_v1';

const START_VENDORS: Vendor[] = [
  { id: 'vndr1', name: 'Swift Errands Co.', cats: ['errands','delivery'], rating: 4.8, price: '$$', etaMin: 60 },
  { id: 'vndr2', name: 'GreenCart (Partner)', cats: ['groceries'], rating: 4.6, price: '$$', etaMin: 120 },
  { id: 'vndr3', name: 'Paws & Walks', cats: ['pet'], rating: 4.9, price: '$', etaMin: 90 },
  { id: 'vndr4', name: 'HomeHero Helpers', cats: ['home'], rating: 4.7, price: '$$$', etaMin: 180 },
];

type Msg = { id: string; role: 'user'|'assistant'|'system'; text: string; ts: string };

type State = {
  member: Member;
  vendors: Vendor[];
  tasks: Task[];
  msgs: Msg[];
  setMember: (m: Partial<Member>) => void;
  addTask: (t: Omit<Task,'id'|'status'|'createdAt'>) => string;
  assignVendor: (taskId: string, v: Vendor) => void;
  advanceStatus: (taskId: string) => void;
  addVendor: (v: Omit<Vendor,'id'>) => void;
  sendMsg: (text: string) => void;
  hydrate: () => Promise<void>;
};

export const useStore = create<State>((set, get) => ({
  member: { planId: '' },
  vendors: START_VENDORS,
  tasks: [],
  msgs: [{ id: uid(), role:'system', text:'Hi! I’m your DayMade concierge. Ask me to handle anything from errands to pet care.', ts: nowISO() }],
  setMember: (m) => { set(s => ({ member: { ...s.member, ...m } })); persist(); },
  addTask: (t) => {
    const id = `T-${uid()}`;
    const task: Task = { ...t, id, status:'new', createdAt: nowISO() };
    set(s => ({ tasks: [task, ...s.tasks] })); persist(); return id;
  },
  assignVendor: (taskId, v) => { set(s => ({ tasks: s.tasks.map(t => t.id===taskId ? { ...t, vendorId: v.id, status:'assigned' } : t) })); persist(); },
  advanceStatus: (taskId) => {
    const STAGES: TaskStatus[] = ['new','assigned','en-route','in-progress','done'];
    set(s => ({ tasks: s.tasks.map(t => t.id===taskId ? { ...t, status: STAGES[Math.min(STAGES.indexOf(t.status)+1, STAGES.length-1)] } : t) }));
    persist();
  },
  addVendor: (v) => { set(s => ({ vendors: [...s.vendors, { ...v, id: uid() }] })); persist(); },
  sendMsg: (text) => {
    const u = { id: uid(), role:'user' as const, text, ts: nowISO() };
    set(s => ({ msgs: [...s.msgs, u] }));
    setTimeout(() => {
      const cat = (['errands','groceries','pet','home','delivery'] as Category[]).find(c => text.toLowerCase().includes(c)) || 'errands';
      const id = get().addTask({
        title: text.slice(0,60),
        details: text,
        category: cat,
        addressFrom: '',
        addressTo: '',
        urgency: 2,
        scheduledAt: dayjs().add(1, 'hour').toISOString(),
        recurrence: 'none',
        creditsUsed: 1
      });
      const reply = { id: uid(), role:'assistant' as const, ts: nowISO(), text: `Got it! I’ve created a ${cat} task. Ref: ${id}` };
      set(s => ({ msgs: [...s.msgs, reply] }));
      persist();
    }, 400);
  },
  hydrate: async () => {
    const raw = await AsyncStorage.getItem(STORAGE_KEY);
    if (raw) set(JSON.parse(raw));
  },
}));

async function persist() {
  const s = useStore.getState();
  const snapshot = { member: s.member, vendors: s.vendors, tasks: s.tasks, msgs: s.msgs };
  await AsyncStorage.setItem(STORAGE_KEY, JSON.stringify(snapshot));
}
