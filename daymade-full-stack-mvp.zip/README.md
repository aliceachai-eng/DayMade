# DayMade – Full-Stack MVP (Backend + Minimal Frontend Tester)

This starter gives you a working **Express backend** with:
- Stripe Checkout session creation for subscriptions (Basic/Pro/Elite)
- Stripe webhook handler for `checkout.session.completed`
- Twilio WhatsApp webhook that replies + stubs task creation

Also includes a **minimal HTML client** to test Checkout locally. You can wire your React app (in canvas) to this backend by calling `/api/checkout/create`.

## Prereqs
- Node 18+
- Stripe account (test mode OK)
- Twilio account (WhatsApp sandbox enabled)
- (Optional) ngrok for webhooks

## Setup
```bash
cp .env.example .env
# fill in your keys and price IDs
npm install
npm run dev
```
Visit http://localhost:3000 to test creating a Checkout session.

## Webhooks (local)
Use ngrok (or similar) and set these in Stripe/Twilio dashboards:
- Stripe:   https://YOUR-NGROK/webhooks/stripe
- Twilio:   https://YOUR-NGROK/webhooks/twilio

## Folder Structure
- server/
  - routes/checkout.js          # POST /api/checkout/create
  - webhooks/stripe.js          # POST /webhooks/stripe
  - webhooks/twilio.js          # POST /webhooks/twilio (WhatsApp)
  - utils/priceMap.js           # map plan -> Stripe price
  - server.js                   # Express app
- client/index.html             # Minimal checkout tester UI

## Wire your React app
In your React `subscribe(planId)` call:
```js
const res = await fetch("http://localhost:3000/api/checkout/create", {
  method: "POST",
  headers: { "Content-Type": "application/json" },
  body: JSON.stringify({ plan: planId, email }), // pass email if you have it
});
const data = await res.json();
window.location.href = data.url;
```

## Next
- Replace in-memory stubs with your DB (Supabase/Mongo)
- Add Auth (Clerk, Supabase Auth, NextAuth)
- Extend Twilio webhook to insert a Task record
