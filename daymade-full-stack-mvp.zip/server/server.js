import 'dotenv/config';
import express from 'express';
import path from 'path';
import cors from 'cors';
import bodyParser from 'body-parser';
import { fileURLToPath } from 'url';

import checkoutRouter from './routes/checkout.js';
import stripeWebhook from './webhooks/stripe.js';
import twilioWebhook from './webhooks/twilio.js';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = process.env.PORT || 3000;

app.use(cors());

// Stripe webhook requires raw body
app.use('/webhooks/stripe', stripeWebhook);

// For everything else we can use JSON
app.use(bodyParser.json());
app.use('/webhooks/twilio', twilioWebhook);
app.use('/api/checkout', checkoutRouter);

// Minimal static client to test checkout
app.use(express.static(path.join(__dirname, '../client')));

app.listen(PORT, () => {
  console.log(`DayMade server running on http://localhost:${PORT}`);
});
