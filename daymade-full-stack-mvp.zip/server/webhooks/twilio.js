import express from 'express';
import twilio from 'twilio';
const router = express.Router();

router.post('/', express.urlencoded({ extended: false }), async (req, res) => {
  const MessagingResponse = twilio.twiml.MessagingResponse;
  const twiml = new MessagingResponse();

  const from = req.body.From || '';
  const body = (req.body.Body || '').trim();

  // Very simple intent: echo and create a reference
  const ref = Math.random().toString(36).slice(2,7).toUpperCase();
  const reply = `Thanks! We received: "${body}". Your request is queued. Ref: ${ref}`;
  twiml.message(reply);

  // TODO: push this into your DB as a new task; route to a vendor

  res.type('text/xml').send(twiml.toString());
});

export default router;
