export const PRICE_MAP = {
  basic: process.env.STRIPE_PRICE_BASIC,
  pro: process.env.STRIPE_PRICE_PRO,
  elite: process.env.STRIPE_PRICE_ELITE,
};

export function assertPriceForPlan(plan) {
  const id = PRICE_MAP[plan];
  if (!id) throw new Error(`Unknown or unset price for plan: ${plan}`);
  return id;
}
