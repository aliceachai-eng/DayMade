import express from 'express';
import Stripe from 'stripe';
import { assertPriceForPlan } from '../utils/priceMap.js';

const router = express.Router();
const stripe = new Stripe(process.env.STRIPE_SECRET_KEY, { apiVersion: '2024-06-20' });

router.post('/create', async (req, res) => {
  try {
    const { plan, email } = req.body || {};
    const price = assertPriceForPlan(plan);

    const session = await stripe.checkout.sessions.create({
      mode: 'subscription',
      line_items: [{ price, quantity: 1 }],
      success_url: `${process.env.PUBLIC_BASE_URL}/?success=true`,
      cancel_url: `${process.env.PUBLIC_BASE_URL}/?canceled=true`,
      customer_email: email,
      metadata: { plan },
    });

    return res.json({ url: session.url });
  } catch (err) {
    console.error(err);
    res.status(400).send(err.message || 'Checkout error');
  }
});

export default router;
