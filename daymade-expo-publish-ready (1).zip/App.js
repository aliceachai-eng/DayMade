
import { StatusBar } from 'expo-status-bar';
import { Text, View, Image, TouchableOpacity } from 'react-native';

export default function App() {
  return (
    <View style={{flex:1, justifyContent:"center", alignItems:"center", backgroundColor:"#F9FAFB"}}>
      <Image source={require("./assets/logo.png")} style={{width:120, height:120, marginBottom:20}} />
      <Text style={{fontSize:24, fontWeight:"600", color:"#1F2937"}}>Welcome to DayMade</Text>
      <Text style={{fontSize:16, color:"#4B5563", marginVertical:10}}>Your day, made easier.</Text>
      <TouchableOpacity style={{backgroundColor:"#4CAF50", padding:15, borderRadius:12, marginTop:20}}>
        <Text style={{color:"#fff", fontSize:18}}>Get Started</Text>
      </TouchableOpacity>
      <StatusBar style="auto" />
    </View>
  );
}
