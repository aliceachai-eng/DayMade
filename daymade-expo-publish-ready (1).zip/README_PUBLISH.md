
# DayMade Expo App (Publish Ready)

This project is pre-configured for **Expo Publish**.

## Steps to Publish

1. Install dependencies:
```bash
npm install
```

2. Log into your Expo account:
```bash
npx expo login
```

3. Publish your app:
```bash
npx expo publish
```

Expo will give you a **QR code** and a **link** (like https://expo.dev/@your-expo-username/daymade) to open in **Expo Go**.

✅ Done — your DayMade app is instantly live!
